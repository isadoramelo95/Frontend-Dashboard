import React from "react";
import ReactDOM from "react-dom";
import {
  Link,
  Switch,
  Route,
  BrowserRouter as Router,
  NavLink
} from "react-router-dom";
// import { Menu } from "@material-ui/icons";

import "./styles.css";

function PerfilPage(props) {
  return (
    <>
      <div className="body">
        <h1>Cadastrar Perfil</h1>
        <form onSubmit="perfil">
          <label htmlFor="perfil">Perfil</label>
          <br />
          <input
            className="input-perfil"
            type="perfil"
            placeholder="Digite um novo perfil"
            text-align="center"
          />
          <input
            className="button-incluir"
            type="button"
            value="Incluir Perfil"
          />
        </form>
        <h4>Perfis Cadastrados</h4>

        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Perfil</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Diretor</td>
            </tr>
            <tr>
              <td>2</td>
              <td>Gestor</td>
            </tr>
            <tr>
              <td>3</td>
              <td>Gestor de Projetos</td>
            </tr>
            <tr>
              <td>4</td>
              <td>Desenvolvedor</td>
            </tr>
            <tr>
              <td>5</td>
              <td>Estagiário</td>
            </tr>
            <tr>
              <td>6</td>
              <td>Externo/Outros</td>
            </tr>
          </tbody>
        </table>

        <form>
          <input className="button-salvar" type="button" value="Salvar" />
        </form>
      </div>
    </>
  );
}
function App(props) {
  return (
    <Router>
      <div className="nav">
        <h1 className="rb">Reembolso App</h1>
        <p className="welcome">Bem-Vindo, Nicholas!</p>
        <img
          src="https://www.placecage.com/c/60/60/"
          className="icone-usuario"
          alt="icone Usuario"
        />
      </div>

      <Switch>
        <Route exact path="/">
          <PerfilPage />
        </Route>
        <Route path="/novoLancamento">
          <NovoLancamento />
        </Route>
        <Route path="/meuLancamento">
          <MeuLancamento />
        </Route>
        <Route path="/meuPerfil">
          <MeuPerfil />
        </Route>
        <Route path="/usuarios">
          <Usuarios />
        </Route>
        <Route path="/perfis">
          <PerfilPage />
        </Route>
        <Route path="/projetos">
          <Projetos />
        </Route>
        <Route path="/clientes">
          <Clientes />
        </Route>
        <Route path="/tiposDespesa">
          <TiposDespesa />
        </Route>
      </Switch>
      <Route>
        <Switch>
          <div className="sidebar">
            <nav>
              {/* <div className="icon-menu"><Menu /></div> */}
              <h2 className="side-menu">MENU</h2>
              <ul>
                <li>
                  <NavLink to="/novoLancamento" activeClassName="active">
                    Novo Lançamento
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/meuLancamento" activeClassName="active">
                    Meu Lançamento
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/meuPerfil" activeClassName="active">
                    Meu Perfil
                  </NavLink>
                </li>
                <h2 className="side-adm">ADM</h2>
                <li>
                  <NavLink to="/usuarios" activeClassName="active">
                    Usuários
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/perfis" activeClassName="active">
                    Perfis
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/projetos" activeClassName="active">
                    Projetos
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/clientes" activeClassName="active">
                    Clientes
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/tipoDespesas" activeClassName="active">
                    Tipos Despesa
                  </NavLink>
                </li>
              </ul>
            </nav>
          </div>
        </Switch>
      </Route>
    </Router>
  );
}

function NovoLancamento(props) {
  return <h2>Novo Lançamento</h2>;
}
function MeuLancamento(props) {
  return <h2>Meu Lançamento</h2>;
}
function MeuPerfil(props) {
  return <h2>Meu Perfil</h2>;
}
function Usuarios(props) {
  return <h2>Usuários</h2>;
}
function Projetos(props) {
  return <h2>Projetos</h2>;
}
function Clientes(props) {
  return <h2>Clientes</h2>;
}
function TiposDespesa(props) {
  return <h2>Tipos Despesa</h2>;
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
